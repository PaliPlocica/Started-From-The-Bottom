import React from 'react'
import Link from 'gatsby-link'
// zistit classes preco nejdu plus id generovanie class balicek zistit
import classes from './sliderImage.scss'
import slider1 from './images/slider1.jpg'
import slider2 from './images/slider2.jpg'
import slider3 from './images/slider3.jpg'

class SliderImage extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      actualPosition: 1,
      actualPositionImage: '0',
      positionImage: ['-100%','0','100%'],
    }

    this.clickLeft = this.clickLeft.bind(this)
    this.clickRight = this.clickRight.bind(this)
  }

  clickLeft() {
    this.setState({ actualPosition: Number(this.state.actualPosition) - 1 })
    this.setState({ actualPositionImage: this.state.positionImage[Number(this.state.actualPosition)] })
    console.log('left', this.state.positionImage, this.state.actualPositionImage);
  }

  clickRight() {
    this.setState({ actualPosition: Number(this.state.actualPosition) + 1 })
    this.setState({ actualPositionImage: this.state.positionImage[Number(this.state.actualPosition)] })
    console.log('right', this.state.positionImage, this.state.actualPositionImage);
  }

  render() {
    const sliders = [slider1]
    console.log('actualPosition', this.state.actualPosition, this.state.actualPositionImage);
    return (
      <div className='wrapper-slider'>
        <div className='slider'>
          {
            sliders.map((image, i) => {
              return <img src={image} className='slider__img' key={`image-slider-${i}`} style={{ transform: `translateX(${this.state.actualPositionImage})`}}/>
            })
          }
          <button className='slider__left icon-chevron-left' onClick={(this.state.actualPosition > -1) ? this.clickLeft : null}/>
          <button className='slider__right icon-chevron-left' onClick={(this.state.actualPosition < 2) ? this.clickRight : null}/>
        </div>
      </div>
    )
  }
}

export default SliderImage
