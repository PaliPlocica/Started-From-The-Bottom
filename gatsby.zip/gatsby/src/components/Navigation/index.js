import React from 'react'
import Link from 'gatsby-link'
// zistit classes preco nejdu plus id generovanie class balicek zistit
import classes from './navigation.scss'

const Navigation = (props) => {
  return (
    <nav className='wrapper-navigation'>
      {/* {props.ccc} */}
      <div className='navigation'>
        <ul className='navigation__menu'>
          {
            props.menuNavigation.map((title, i) => {
              let menuLi
              (title === 'Blog') ? (
                menuLi = (
                  <li className='navigation__menu__li' key={`navigation-menu-${i}`}>
                    <Link to='/blog/' className='navigation__menu__li__a'>{title}</Link>
                  </li>
                )
              )
                : (
                  menuLi = (
                    <li className='navigation__menu__li' key={`navigation-menu-${i}`}>
                      <a href='#' className='navigation__menu__li__a'>{title}</a>
                    </li>
                  )
                )
              return menuLi
            })
          }
        </ul>
      </div>
    </nav>
  )
}

export default Navigation
