import React from 'react'
import Link from 'gatsby-link'

const SecondPage = () => (
  <div>
    <Link to='/'>back</Link>
    
  </div>
)

export default SecondPage
