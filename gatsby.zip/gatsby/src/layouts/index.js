import React from 'react'
import PropTypes from 'prop-types'

import reset from 'reset-css';
import './layout.scss'
import '../styles/core.scss'

import Helmet from 'react-helmet'
import Navigation from '../components/Navigation'
import SliderImage from '../components/SliderImage'

const TemplateWrapper = ({ children }) => {
  const listMenuItems = ['comiXzone', 'Home', 'Blog', 'News', 'Shops', 'Contacts']
  return (
    <div className='container'>
      <Helmet
        title="comiXzone"
        meta={[
          { name: 'description', content: 'comics' },
          { name: 'keywords', content: 'super duper comics' },
        ]}
      />
      <Navigation menuNavigation={listMenuItems} ccc='aaa' />
      <div className='container__content'>
        <SliderImage />
        {children()}
      </div>
    </div>
  )
}


TemplateWrapper.propTypes = {
  children: PropTypes.func,
}

export default TemplateWrapper
