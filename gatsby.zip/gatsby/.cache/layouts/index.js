
  import React from "react"
  import Component from "C:/Users/lfrantal/Documents/project/gatsby/src/layouts/index.js"
  import data from "C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\layout-index.json"

  export default (props) => <Component {...props} {...data} />
  