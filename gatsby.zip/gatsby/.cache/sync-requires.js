// prefer default export if available
const preferDefault = m => m && m.default || m


exports.layouts = {
  "layout---index": preferDefault(require("C:/Users/lfrantal/Documents/project/gatsby/.cache/layouts/index.js"))
}

exports.components = {
  "component---cache-dev-404-page-js": preferDefault(require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\dev-404-page.js")),
  "component---src-pages-404-js": preferDefault(require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\src\\pages\\404.js")),
  "component---src-pages-blog-js": preferDefault(require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\src\\pages\\blog.js")),
  "component---src-pages-index-js": preferDefault(require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\src\\pages\\index.js"))
}

exports.json = {
  "layout-index.json": require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\layout-index.json"),
  "dev-404-page.json": require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\dev-404-page.json"),
  "404.json": require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\404.json"),
  "blog.json": require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\blog.json"),
  "index.json": require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\index.json"),
  "404-html.json": require("C:\\Users\\lfrantal\\Documents\\project\\gatsby\\.cache\\json\\404-html.json")
}