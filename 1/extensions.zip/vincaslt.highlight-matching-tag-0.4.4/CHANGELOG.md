# Change Log
All notable changes to the "higlight-matching-tag" extension will be documented in this file.

## [0.1.0]

* Initial release of __highlight-matching-tag__

## 0.2.0

* Highlight multiline tags correctly
* Options for customizing left-right sides of highlighting
* Documentation updates

### 0.3.0

* Match opening tag from closing tag