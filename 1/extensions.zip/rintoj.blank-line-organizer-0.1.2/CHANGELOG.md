# v0.1.2

* feature: apply only to selected text (fixes #2)

# v0.1.1

* minor bug fixes

# v0.1.0

* add: react support (updated default configuration)

# v0.1.0
* fix: performance issues

# v0.0.2
* Minor bug fix.

# v0.0.1
* Initial version