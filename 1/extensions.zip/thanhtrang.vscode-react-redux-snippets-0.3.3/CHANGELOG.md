# Change Log
All notable changes to the "vscode-react-redux-snippets" extension will be documented in this file.

## [Unreleased]

## [0.3.3] - 2017-05-31
Fix typo

## [0.3.2] - 2017-05-31
Using prop-types lib because PropTypes was deprecated after React 15.5

## [0.3.1] - 2017-04-25
Remove duplicated snippets

## [0.3.0] - 2017-04-24
Add support semicolon
Fix typo

## [0.2.2] - 2017-04-14
Fix typo

## [0.2.1] - 2017-04-14
Add import snippet for suggestion
Using bindActionCreators for mapDispatchToProps

## [0.2.0] - 2017-04-10
Default propTypes and defaultProps now is null Object

## [0.1.4] - 2017-03-17
Add Redux Component snippet
Fix setState using function instead of object

## [0.0.1] - 2017-03-08
First release