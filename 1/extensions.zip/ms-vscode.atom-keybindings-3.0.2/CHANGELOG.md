## 3.0.1
- Map `cmd+y`, `ctrl+y` to redo (thank you @ianaya89!)
- Readme.md fix (thank you @glingy!)

## 3.0
- Added settings for multi cursor mouse mapping and enabling format on paste by default. 

## 2.0
- Added default settings: minimap and format on paste
- File tree view keyboard shortcuts migrated

## 1.0
- Initial migration of keyboard shortcuts